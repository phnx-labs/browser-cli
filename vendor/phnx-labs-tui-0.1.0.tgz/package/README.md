# tui

`@phnx-labs/tui`: the terminal UI shared by the standalone `sessions`, `browser`
and `computer` CLIs. It provides a type-to-filter picker with a preview pane, a
printed list with a count footer, format helpers, and a stdout writer that is
safe to pipe.

```
bun add @phnx-labs/tui
```

```ts
import { isInteractiveTerminal, itemPicker, printList, printJson, formatColumns, formatRelativeTime } from '@phnx-labs/tui';

if (opts.json) printJson(rows);
else if (!isInteractiveTerminal()) {
  printList({
    rows, noun: 'run', limit: opts.limit, narrowHint: '--search or --since to narrow',
    render: (shown) => formatColumns(shown.map((r) => [r.task, r.machine, formatRelativeTime(r.endIso)])),
  });
} else {
  const picked = await itemPicker({
    message: 'History:', items: rows,
    filter: (q) => rows.filter((r) => r.task.includes(q)),
    labelFor: (r) => r.task, buildPreview: (r) => r.detail, enterHint: 'open',
  });
}
```

`itemPicker`, `multiItemPicker` and `dynamicPicker` load `@inquirer/core` on
first use, so a command that only prints never loads it. `printJson`,
`printList`, `printLine` and `writeOut` write synchronously and finish the
write even when Bun has made fd 1 non-blocking, so output past 64 KiB reaches a
pipe intact. See [AGENTS.md](AGENTS.md) for the rule behind this and for how the
earlier copies differed.

Keys in the picker: type to filter, ↑↓ to move, space to show or hide the
preview (with an empty query), Enter to pick, Escape to cancel.

# Changelog

## 0.1.0 — 2026-10-05

- First release, extracted from agents-cli and the sessions, browser and computer
  CLIs (PHNX-4227): `itemPicker`, `multiItemPicker` and `dynamicPicker` (loaded
  lazily), `createPickerCommand`, `printList` with a count footer and `--limit`
  hint, `formatColumns`, width-aware truncation, relative ages, and pipe-safe
  `writeOut`/`printLine`/`printJson`.
